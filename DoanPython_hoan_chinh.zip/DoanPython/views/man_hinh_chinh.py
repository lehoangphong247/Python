import customtkinter as ctk
from tkinter import messagebox
from datetime import date
from models.giao_dich import GiaoDich
from views.quan_ly_giao_dich import QuanLyGiaoDich
from views.quan_ly_danh_muc import QuanLyDanhMuc
from views.quan_ly_ngan_sach import QuanLyNganSach
from views.thong_ke import ThongKe
from utils.xuat_bao_cao import xuat_bao_cao_csv


class ManHinhChinh(ctk.CTkFrame):
    def __init__(self, master, nguoi_dung):
        super().__init__(master, fg_color="#F3F6FB")
        self.master = master
        self.nguoi_dung = nguoi_dung
        self.user_id = nguoi_dung["id"]
        self.tao_giao_dien()

    def tao_giao_dien(self):
        self.sidebar = ctk.CTkFrame(self, width=225, fg_color="#173B67", corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        ctk.CTkLabel(self.sidebar, text="FINANCE\nMANAGER",
                     font=("Arial", 23, "bold"), text_color="white",
                     justify="left").pack(anchor="w", padx=25, pady=(35, 45))
        ctk.CTkLabel(self.sidebar, text=f"Xin chào, {self.nguoi_dung['ho_ten']}",
                     font=("Arial", 13, "bold"), text_color="#D5E3F5",
                     wraplength=180).pack(anchor="w", padx=20, pady=(0, 20))

        cac_nut = [
            ("Tổng quan", self.hien_tong_quan),
            ("Quản lý giao dịch", self.hien_giao_dich),
            ("Quản lý danh mục", self.hien_danh_muc),
            ("Quản lý ngân sách", self.hien_ngan_sach),
            ("Thống kê", self.hien_thong_ke),
            ("Xuất báo cáo CSV", self.xuat_bao_cao)
        ]
        for ten, ham in cac_nut:
            ctk.CTkButton(
                self.sidebar, text=ten, anchor="w", height=43,
                fg_color="transparent", hover_color="#285583",
                text_color="white", font=("Arial", 14),
                command=ham
            ).pack(fill="x", padx=12, pady=4)

        ctk.CTkButton(
            self.sidebar, text="Đăng xuất", height=42,
            fg_color="#A33D4B", hover_color="#87313D",
            command=self.dang_xuat
        ).pack(side="bottom", fill="x", padx=12, pady=20)

        self.noi_dung = ctk.CTkFrame(self, fg_color="#F3F6FB", corner_radius=0)
        self.noi_dung.pack(side="left", fill="both", expand=True)
        self.hien_tong_quan()

    def xoa_noi_dung(self):
        for widget in self.noi_dung.winfo_children():
            widget.destroy()

    def tieu_de(self, ten, mo_ta=""):
        ctk.CTkLabel(self.noi_dung, text=ten, font=("Arial", 27, "bold"),
                     text_color="#173B67").pack(anchor="w", padx=30, pady=(28, 5))
        if mo_ta:
            ctk.CTkLabel(self.noi_dung, text=mo_ta, font=("Arial", 13),
                         text_color="#718096").pack(anchor="w", padx=30, pady=(0, 18))

    def hien_tong_quan(self):
        self.xoa_noi_dung()
        self.tieu_de("Tổng quan", "Tình hình tài chính cá nhân của bạn")
        tong = GiaoDich.tong_quan(self.user_id)
        thu = tong["Thu nhập"]
        chi = tong["Chi tiêu"]
        so_du = thu - chi

        hang = ctk.CTkFrame(self.noi_dung, fg_color="transparent")
        hang.pack(fill="x", padx=25, pady=15)
        the_data = [
            ("TỔNG THU NHẬP", thu, "#E5F5EC", "#16834A"),
            ("TỔNG CHI TIÊU", chi, "#FCEBEC", "#C43D4B"),
            ("SỐ DƯ HIỆN TẠI", so_du, "#E8F0FC", "#2563EB")
        ]
        for nhan, so_tien, nen, mau in the_data:
            the = ctk.CTkFrame(hang, fg_color=nen, corner_radius=14, height=125)
            the.pack(side="left", fill="x", expand=True, padx=7)
            ctk.CTkLabel(the, text=nhan, font=("Arial", 12, "bold"),
                         text_color=mau).pack(anchor="w", padx=18, pady=(20, 8))
            ctk.CTkLabel(the, text=f"{so_tien:,.0f} đ",
                         font=("Arial", 23, "bold"), text_color=mau).pack(anchor="w", padx=18)

        ctk.CTkLabel(self.noi_dung, text="Bắt đầu quản lý tài chính của bạn",
                     font=("Arial", 19, "bold"), text_color="#173B67").pack(anchor="w", padx=32, pady=(35, 10))
        ctk.CTkLabel(
            self.noi_dung,
            text="Sử dụng thanh chức năng bên trái để thêm giao dịch, đặt ngân sách\n"
                 "và theo dõi tình hình thu chi của bạn.",
            font=("Arial", 14), text_color="#64748B", justify="left"
        ).pack(anchor="w", padx=32)

    def hien_giao_dich(self):
        self.xoa_noi_dung()
        QuanLyGiaoDich(self.noi_dung, self.user_id, self.hien_giao_dich).pack(fill="both", expand=True)

    def hien_danh_muc(self):
        self.xoa_noi_dung()
        QuanLyDanhMuc(self.noi_dung, self.user_id, self.hien_danh_muc).pack(fill="both", expand=True)

    def hien_ngan_sach(self):
        self.xoa_noi_dung()
        QuanLyNganSach(self.noi_dung, self.user_id).pack(fill="both", expand=True)

    def hien_thong_ke(self):
        self.xoa_noi_dung()
        ThongKe(self.noi_dung, self.user_id).pack(fill="both", expand=True)

    def xuat_bao_cao(self):
        xuat_bao_cao_csv(self.user_id)

    def dang_xuat(self):
        from views.man_hinh_dang_nhap import ManHinhDangNhap
        if messagebox.askyesno("Đăng xuất", "Bạn có chắc muốn đăng xuất?"):
            self.destroy()
            ManHinhDangNhap(self.master).pack(fill="both", expand=True)
