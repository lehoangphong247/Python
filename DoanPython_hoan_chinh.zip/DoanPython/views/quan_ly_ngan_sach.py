import customtkinter as ctk
from tkinter import messagebox
from datetime import date
from models.ngan_sach import NganSach
from models.giao_dich import GiaoDich


class QuanLyNganSach(ctk.CTkFrame):
    def __init__(self, master, user_id):
        super().__init__(master, fg_color="#F3F6FB")
        self.user_id = user_id
        self.tao_giao_dien()
        self.tai_du_lieu()

    def tao_giao_dien(self):
        ctk.CTkLabel(self, text="Quản lý ngân sách", font=("Arial", 27, "bold"),
                     text_color="#173B67").pack(anchor="w", padx=30, pady=(28, 8))
        ctk.CTkLabel(self, text="Đặt giới hạn chi tiêu cho từng tháng",
                     text_color="#718096").pack(anchor="w", padx=30, pady=(0, 18))
        form = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        form.pack(fill="x", padx=25, pady=8)
        self.thang = ctk.CTkEntry(form, placeholder_text="YYYY-MM", width=150)
        self.thang.insert(0, date.today().strftime("%Y-%m"))
        self.thang.pack(side="left", padx=15, pady=18)
        self.so_tien = ctk.CTkEntry(form, placeholder_text="Ngân sách (VND)", width=200)
        self.so_tien.pack(side="left", padx=10)
        ctk.CTkButton(form, text="Lưu ngân sách", command=self.luu).pack(side="left", padx=10)
        self.ket_qua = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        self.ket_qua.pack(fill="x", padx=25, pady=15)

    def luu(self):
        thang = self.thang.get().strip()
        try:
            if len(thang) != 7 or thang[4] != "-":
                raise ValueError
            nam, th = map(int, thang.split("-"))
            if th < 1 or th > 12 or nam < 2000:
                raise ValueError
            so_tien = float(self.so_tien.get().replace(",", "").replace(" ", ""))
            if so_tien <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Dữ liệu không hợp lệ", "Nhập tháng YYYY-MM và ngân sách lớn hơn 0.")
            return
        NganSach.luu(self.user_id, thang, so_tien)
        messagebox.showinfo("Thành công", "Đã lưu ngân sách.")
        self.tai_du_lieu()

    def tai_du_lieu(self):
        for w in self.ket_qua.winfo_children():
            w.destroy()
        thang = self.thang.get().strip()
        ngan_sach = NganSach.lay(self.user_id, thang)
        thong_ke = GiaoDich.thong_ke_thang(self.user_id, thang)
        da_chi = thong_ke["Chi tiêu"]
        if ngan_sach:
            muc = ngan_sach["so_tien"]
            con_lai = muc - da_chi
            ctk.CTkLabel(self.ket_qua, text=f"Ngân sách tháng {thang}: {muc:,.0f} đ",
                         font=("Arial", 17, "bold"), text_color="#173B67").pack(anchor="w", padx=20, pady=(18, 8))
            ctk.CTkLabel(self.ket_qua, text=f"Đã chi: {da_chi:,.0f} đ",
                         font=("Arial", 14), text_color="#C43D4B").pack(anchor="w", padx=20, pady=4)
            ctk.CTkLabel(self.ket_qua, text=f"Còn lại: {con_lai:,.0f} đ",
                         font=("Arial", 14), text_color="#16834A" if con_lai >= 0 else "#C43D4B").pack(anchor="w", padx=20, pady=(4, 18))
        else:
            ctk.CTkLabel(self.ket_qua, text="Chưa có ngân sách cho tháng này.",
                         text_color="#64748B").pack(padx=20, pady=20)
