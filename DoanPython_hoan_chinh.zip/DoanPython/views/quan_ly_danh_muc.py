import customtkinter as ctk
from tkinter import messagebox
from models.danh_muc import DanhMuc


class QuanLyDanhMuc(ctk.CTkFrame):
    def __init__(self, master, user_id, lam_moi):
        super().__init__(master, fg_color="#F3F6FB")
        self.user_id = user_id
        self.lam_moi = lam_moi
        self.tao_giao_dien()
        self.tai_du_lieu()

    def tao_giao_dien(self):
        ctk.CTkLabel(self, text="Quản lý danh mục", font=("Arial", 27, "bold"),
                     text_color="#173B67").pack(anchor="w", padx=30, pady=(28, 18))
        form = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        form.pack(fill="x", padx=25, pady=8)
        self.ten = ctk.CTkEntry(form, placeholder_text="Tên danh mục", width=250)
        self.ten.pack(side="left", padx=15, pady=18)
        self.loai = ctk.CTkOptionMenu(form, values=["Chi tiêu", "Thu nhập"])
        self.loai.pack(side="left", padx=10)
        ctk.CTkButton(form, text="Thêm danh mục", command=self.them).pack(side="left", padx=10)
        self.ds = ctk.CTkScrollableFrame(self, fg_color="white", corner_radius=12)
        self.ds.pack(fill="both", expand=True, padx=25, pady=12)

    def them(self):
        ten = self.ten.get().strip()
        if not ten:
            messagebox.showwarning("Thiếu thông tin", "Nhập tên danh mục.")
            return
        ok, tb = DanhMuc.them(self.user_id, ten, self.loai.get())
        if ok:
            self.ten.delete(0, "end")
            self.tai_du_lieu()
        else:
            messagebox.showerror("Không thể thêm", tb)

    def tai_du_lieu(self):
        for w in self.ds.winfo_children():
            w.destroy()
        for dm in DanhMuc.lay_tat_ca(self.user_id):
            dong = ctk.CTkFrame(self.ds, fg_color="#F5F8FC", corner_radius=8)
            dong.pack(fill="x", padx=5, pady=4)
            ctk.CTkLabel(dong, text=f"{dm['ten']}   —   {dm['loai']}",
                         anchor="w").pack(side="left", fill="x", expand=True, padx=12, pady=12)
            ctk.CTkButton(dong, text="Xóa", width=65, fg_color="#B64250",
                          command=lambda ma=dm["id"]: self.xoa(ma)).pack(side="right", padx=8, pady=6)

    def xoa(self, ma):
        if messagebox.askyesno("Xác nhận", "Xóa danh mục này? Giao dịch cũ vẫn được giữ."):
            DanhMuc.xoa(self.user_id, ma)
            self.tai_du_lieu()
