import customtkinter as ctk
from tkinter import messagebox
from models.nguoi_dung import NguoiDung


class ManHinhDangNhap(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="#F3F6FB")
        self.master = master
        self.tao_giao_dien()

    def tao_giao_dien(self):
        trai = ctk.CTkFrame(self, width=390, corner_radius=0, fg_color="#173B67")
        trai.pack(side="left", fill="y")
        trai.pack_propagate(False)

        ctk.CTkLabel(trai, text="FINANCE MANAGER",
                     font=("Arial", 24, "bold"), text_color="white").pack(pady=(120, 35))
        ctk.CTkLabel(trai, text="QUẢN LÝ CHI TIÊU\nTHÔNG MINH",
                     font=("Arial", 30, "bold"), text_color="white",
                     justify="center").pack(pady=15)
        ctk.CTkLabel(trai, text="Kiểm soát tài chính cá nhân\nBắt đầu từ những thay đổi nhỏ.",
                     font=("Arial", 15), text_color="#D5E3F5",
                     justify="center").pack(pady=15)
        ctk.CTkLabel(trai, text="Theo dõi  •  Tiết kiệm  •  Phát triển",
                     font=("Arial", 13), text_color="#B9CDE5").pack(side="bottom", pady=40)

        phai = ctk.CTkFrame(self, fg_color="white", corner_radius=0)
        phai.pack(side="left", fill="both", expand=True)

        form = ctk.CTkFrame(phai, fg_color="white", width=430, height=500)
        form.place(relx=0.5, rely=0.5, anchor="center")
        form.pack_propagate(False)

        ctk.CTkLabel(form, text="Chào mừng trở lại!",
                     font=("Arial", 29, "bold"), text_color="#173B67").pack(anchor="w", pady=(25, 8))
        ctk.CTkLabel(form, text="Đăng nhập để tiếp tục quản lý chi tiêu",
                     font=("Arial", 14), text_color="#718096").pack(anchor="w", pady=(0, 32))

        ctk.CTkLabel(form, text="Tên đăng nhập", font=("Arial", 14, "bold"),
                     text_color="#334155").pack(anchor="w", pady=(0, 7))
        self.ten_dang_nhap = ctk.CTkEntry(
            form, height=46, placeholder_text="Nhập tên đăng nhập",
            border_color="#D5DFEC", corner_radius=9, font=("Arial", 14)
        )
        self.ten_dang_nhap.pack(fill="x", pady=(0, 20))

        ctk.CTkLabel(form, text="Mật khẩu", font=("Arial", 14, "bold"),
                     text_color="#334155").pack(anchor="w", pady=(0, 7))
        self.mat_khau = ctk.CTkEntry(
            form, height=46, placeholder_text="Nhập mật khẩu",
            show="*", border_color="#D5DFEC", corner_radius=9, font=("Arial", 14)
        )
        self.mat_khau.pack(fill="x", pady=(0, 12))

        self.hien_mat_khau = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            form, text="Hiển thị mật khẩu", variable=self.hien_mat_khau,
            command=self.doi_hien_mat_khau, text_color="#64748B"
        ).pack(anchor="w", pady=(0, 22))

        ctk.CTkButton(
            form, text="ĐĂNG NHẬP", height=48, corner_radius=9,
            font=("Arial", 15, "bold"), command=self.xu_ly_dang_nhap
        ).pack(fill="x", pady=(0, 20))

        hang = ctk.CTkFrame(form, fg_color="white")
        hang.pack()
        ctk.CTkLabel(hang, text="Bạn chưa có tài khoản?",
                     text_color="#64748B").pack(side="left")
        ctk.CTkButton(
            hang, text="Đăng ký ngay", width=110, fg_color="transparent",
            text_color="#2563EB", hover_color="#EFF6FF",
            command=self.mo_dang_ky
        ).pack(side="left")

    def doi_hien_mat_khau(self):
        self.mat_khau.configure(show="" if self.hien_mat_khau.get() else "*")

    def xu_ly_dang_nhap(self):
        from views.man_hinh_chinh import ManHinhChinh
        ten = self.ten_dang_nhap.get().strip()
        mat_khau = self.mat_khau.get()
        if not ten or not mat_khau:
            messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập tên đăng nhập và mật khẩu.")
            return

        nguoi_dung = NguoiDung.dang_nhap(ten, mat_khau)
        if nguoi_dung:
            self.destroy()
            ManHinhChinh(self.master, nguoi_dung).pack(fill="both", expand=True)
        else:
            messagebox.showerror("Đăng nhập thất bại", "Tên đăng nhập hoặc mật khẩu không đúng.")

    def mo_dang_ky(self):
        from views.man_hinh_dang_ki import ManHinhDangKy
        self.destroy()
        ManHinhDangKy(self.master).pack(fill="both", expand=True)
