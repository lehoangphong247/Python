import customtkinter as ctk
from tkinter import messagebox
from datetime import date
from models.giao_dich import GiaoDich
from models.danh_muc import DanhMuc


class QuanLyGiaoDich(ctk.CTkFrame):
    def __init__(self, master, user_id, lam_moi):
        super().__init__(master, fg_color="#F3F6FB")
        self.user_id = user_id
        self.lam_moi = lam_moi
        self.danh_sach = []
        self.tao_giao_dien()
        self.tai_du_lieu()

    def tao_giao_dien(self):
        ctk.CTkLabel(self, text="Quản lý giao dịch", font=("Arial", 27, "bold"),
                     text_color="#173B67").pack(anchor="w", padx=30, pady=(28, 5))
        ctk.CTkLabel(self, text="Thêm, xem và xóa các khoản thu chi",
                     text_color="#718096").pack(anchor="w", padx=30, pady=(0, 15))

        form = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        form.pack(fill="x", padx=25, pady=8)

        self.loai = ctk.CTkOptionMenu(form, values=["Chi tiêu", "Thu nhập"], command=self.cap_nhat_danh_muc)
        self.loai.grid(row=0, column=0, padx=10, pady=15)
        self.danh_muc = ctk.CTkOptionMenu(form, values=["Chưa có danh mục"])
        self.danh_muc.grid(row=0, column=1, padx=10, pady=15)
        self.so_tien = ctk.CTkEntry(form, placeholder_text="Số tiền (VND)", width=150)
        self.so_tien.grid(row=0, column=2, padx=10, pady=15)
        self.ngay = ctk.CTkEntry(form, placeholder_text="YYYY-MM-DD", width=130)
        self.ngay.insert(0, date.today().isoformat())
        self.ngay.grid(row=0, column=3, padx=10, pady=15)
        self.ghi_chu = ctk.CTkEntry(form, placeholder_text="Ghi chú", width=170)
        self.ghi_chu.grid(row=0, column=4, padx=10, pady=15)
        ctk.CTkButton(form, text="Thêm giao dịch", command=self.them).grid(row=0, column=5, padx=10, pady=15)

        self.bang = ctk.CTkScrollableFrame(self, fg_color="white", corner_radius=12)
        self.bang.pack(fill="both", expand=True, padx=25, pady=12)
        self.cap_nhat_danh_muc()

    def cap_nhat_danh_muc(self, _=None):
        loai = self.loai.get()
        self.ds_danh_muc = DanhMuc.lay_tat_ca(self.user_id, loai)
        ten = [d["ten"] for d in self.ds_danh_muc] or ["Chưa có danh mục"]
        self.danh_muc.configure(values=ten)
        self.danh_muc.set(ten[0])

    def them(self):
        try:
            so_tien = float(self.so_tien.get().replace(",", "").replace(" ", ""))
            if so_tien <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Dữ liệu không hợp lệ", "Số tiền phải là số lớn hơn 0.")
            return

        ngay = self.ngay.get().strip()
        try:
            date.fromisoformat(ngay)
        except ValueError:
            messagebox.showerror("Ngày không hợp lệ", "Nhập ngày theo định dạng YYYY-MM-DD.")
            return

        ten_dm = self.danh_muc.get()
        dm = next((d for d in self.ds_danh_muc if d["ten"] == ten_dm), None)
        if not dm:
            messagebox.showwarning("Thiếu danh mục", "Bạn cần tạo danh mục phù hợp trước.")
            return

        ok, thong_bao = GiaoDich.them(
            self.user_id, dm["id"], self.loai.get(), so_tien, ngay, self.ghi_chu.get()
        )
        if ok:
            messagebox.showinfo("Thành công", thong_bao)
            self.so_tien.delete(0, "end")
            self.ghi_chu.delete(0, "end")
            self.tai_du_lieu()
        else:
            messagebox.showerror("Lỗi", thong_bao)

    def tai_du_lieu(self):
        for w in self.bang.winfo_children():
            w.destroy()
        self.danh_sach = GiaoDich.lay_tat_ca(self.user_id)
        for row in self.danh_sach:
            dong = ctk.CTkFrame(self.bang, fg_color="#F5F8FC", corner_radius=8)
            dong.pack(fill="x", padx=5, pady=4)
            noi_dung = f"{row['ngay']}   |   {row['loai']}   |   {row['ten_danh_muc'] or 'Không có danh mục'}   |   {row['so_tien']:,.0f} đ   |   {row['ghi_chu'] or ''}"
            ctk.CTkLabel(dong, text=noi_dung, anchor="w").pack(side="left", fill="x", expand=True, padx=12, pady=12)
            ctk.CTkButton(dong, text="Xóa", width=65, fg_color="#B64250",
                          hover_color="#963541",
                          command=lambda ma=row["id"]: self.xoa(ma)).pack(side="right", padx=8, pady=6)

    def xoa(self, giao_dich_id):
        if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa giao dịch này?"):
            GiaoDich.xoa(self.user_id, giao_dich_id)
            self.tai_du_lieu()
