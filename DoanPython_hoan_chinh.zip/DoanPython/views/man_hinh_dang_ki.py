import customtkinter as ctk
from tkinter import messagebox
from models.nguoi_dung import NguoiDung


class ManHinhDangKy(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="#F3F6FB")
        self.master = master
        self.tao_giao_dien()

    def tao_giao_dien(self):
        trai = ctk.CTkFrame(self, width=390, corner_radius=0, fg_color="#173B67")
        trai.pack(side="left", fill="y")
        trai.pack_propagate(False)
        ctk.CTkLabel(trai, text="FINANCE MANAGER",
                     font=("Arial", 24, "bold"), text_color="white").pack(pady=(120, 35))
        ctk.CTkLabel(trai, text="BẮT ĐẦU HÀNH TRÌNH\nTÀI CHÍNH CỦA BẠN",
                     font=("Arial", 26, "bold"), text_color="white",
                     justify="center").pack(pady=15)
        ctk.CTkLabel(trai, text="Tạo tài khoản để quản lý\nchi tiêu cá nhân hiệu quả.",
                     font=("Arial", 15), text_color="#D5E3F5",
                     justify="center").pack(pady=15)

        phai = ctk.CTkFrame(self, fg_color="white", corner_radius=0)
        phai.pack(side="left", fill="both", expand=True)
        form = ctk.CTkFrame(phai, fg_color="white", width=440, height=620)
        form.place(relx=0.5, rely=0.5, anchor="center")
        form.pack_propagate(False)

        ctk.CTkLabel(form, text="Tạo tài khoản",
                     font=("Arial", 28, "bold"), text_color="#173B67").pack(anchor="w", pady=(8, 5))
        ctk.CTkLabel(form, text="Điền thông tin để bắt đầu sử dụng ứng dụng",
                     font=("Arial", 13), text_color="#718096").pack(anchor="w", pady=(0, 18))

        self.ho_ten = self.tao_o_nhap(form, "Họ và tên", "Nhập họ và tên")
        self.ten_dang_nhap = self.tao_o_nhap(form, "Tên đăng nhập", "Tạo tên đăng nhập")
        self.mat_khau = self.tao_o_nhap(form, "Mật khẩu", "Tối thiểu 6 ký tự", True)
        self.xac_nhan = self.tao_o_nhap(form, "Xác nhận mật khẩu", "Nhập lại mật khẩu", True)

        ctk.CTkButton(form, text="ĐĂNG KÝ", height=48, corner_radius=9,
                      font=("Arial", 15, "bold"), command=self.xu_ly_dang_ky).pack(fill="x", pady=(10, 18))

        hang = ctk.CTkFrame(form, fg_color="white")
        hang.pack()
        ctk.CTkLabel(hang, text="Đã có tài khoản?", text_color="#64748B").pack(side="left")
        ctk.CTkButton(hang, text="Đăng nhập", width=100, fg_color="transparent",
                      text_color="#2563EB", hover_color="#EFF6FF",
                      command=self.quay_lai).pack(side="left")

    def tao_o_nhap(self, khung, nhan, goi_y, an=False):
        ctk.CTkLabel(khung, text=nhan, font=("Arial", 14, "bold"),
                     text_color="#334155").pack(anchor="w", pady=(0, 5))
        o = ctk.CTkEntry(khung, height=43, placeholder_text=goi_y,
                         show="*" if an else "", corner_radius=9,
                         border_color="#D5DFEC", font=("Arial", 14))
        o.pack(fill="x", pady=(0, 12))
        return o

    def xu_ly_dang_ky(self):
        ho_ten = self.ho_ten.get().strip()
        ten = self.ten_dang_nhap.get().strip()
        mat_khau = self.mat_khau.get()
        xac_nhan = self.xac_nhan.get()

        if not all([ho_ten, ten, mat_khau, xac_nhan]):
            messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập đầy đủ thông tin.")
            return
        if mat_khau != xac_nhan:
            messagebox.showerror("Lỗi", "Mật khẩu xác nhận không khớp.")
            return

        thanh_cong, thong_bao = NguoiDung.dang_ky(ho_ten, ten, mat_khau)
        if thanh_cong:
            messagebox.showinfo("Thành công", thong_bao + "\nBạn có thể đăng nhập.")
            self.quay_lai()
        else:
            messagebox.showerror("Không thể đăng ký", thong_bao)

    def quay_lai(self):
        from views.man_hinh_dang_nhap import ManHinhDangNhap
        self.destroy()
        ManHinhDangNhap(self.master).pack(fill="both", expand=True)
