import customtkinter as ctk
from datetime import date
from models.giao_dich import GiaoDich


class ThongKe(ctk.CTkFrame):
    def __init__(self, master, user_id):
        super().__init__(master, fg_color="#F3F6FB")
        self.user_id = user_id
        self.tao_giao_dien()

    def tao_giao_dien(self):
        ctk.CTkLabel(self, text="Thống kê chi tiêu", font=("Arial", 27, "bold"),
                     text_color="#173B67").pack(anchor="w", padx=30, pady=(28, 8))
        ctk.CTkLabel(self, text="Thống kê thu nhập và chi tiêu theo tháng",
                     text_color="#718096").pack(anchor="w", padx=30, pady=(0, 15))

        hang = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        hang.pack(fill="x", padx=25, pady=8)
        self.thang = ctk.CTkEntry(hang, width=150, placeholder_text="YYYY-MM")
        self.thang.insert(0, date.today().strftime("%Y-%m"))
        self.thang.pack(side="left", padx=15, pady=15)
        ctk.CTkButton(hang, text="Xem thống kê", command=self.cap_nhat).pack(side="left", padx=8)

        self.ket_qua = ctk.CTkFrame(self, fg_color="white", corner_radius=12)
        self.ket_qua.pack(fill="both", expand=True, padx=25, pady=15)
        self.cap_nhat()

    def cap_nhat(self):
        thang = self.thang.get().strip()
        for w in self.ket_qua.winfo_children():
            w.destroy()
        if len(thang) != 7 or thang[4] != "-":
            ctk.CTkLabel(self.ket_qua, text="Vui lòng nhập tháng theo dạng YYYY-MM.").pack(pady=20)
            return

        data = GiaoDich.thong_ke_thang(self.user_id, thang)
        thu = data["Thu nhập"]
        chi = data["Chi tiêu"]
        so_du = thu - chi
        for nhan, gia_tri, mau in [
            ("Tổng thu nhập", thu, "#16834A"),
            ("Tổng chi tiêu", chi, "#C43D4B"),
            ("Chênh lệch thu - chi", so_du, "#2563EB")
        ]:
            khoi = ctk.CTkFrame(self.ket_qua, fg_color="#F3F6FB", corner_radius=10)
            khoi.pack(fill="x", padx=18, pady=10)
            ctk.CTkLabel(khoi, text=nhan, font=("Arial", 14, "bold"),
                         text_color="#334155").pack(anchor="w", padx=15, pady=(12, 4))
            ctk.CTkLabel(khoi, text=f"{gia_tri:,.0f} đ", font=("Arial", 22, "bold"),
                         text_color=mau).pack(anchor="w", padx=15, pady=(0, 12))
