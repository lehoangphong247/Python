import hashlib
import hmac
import os


def bam_mat_khau(mat_khau):
    """Băm mật khẩu bằng PBKDF2-HMAC-SHA256 trước khi lưu."""
    salt = os.urandom(16)
    vong_lap = 200_000
    ket_qua = hashlib.pbkdf2_hmac(
        "sha256", mat_khau.encode("utf-8"), salt, vong_lap
    )
    return f"{vong_lap}${salt.hex()}${ket_qua.hex()}"


def kiem_tra_mat_khau(mat_khau, chuoi_da_bam):
    try:
        vong_lap, salt_hex, hash_hex = chuoi_da_bam.split("$")
        ket_qua = hashlib.pbkdf2_hmac(
            "sha256",
            mat_khau.encode("utf-8"),
            bytes.fromhex(salt_hex),
            int(vong_lap)
        )
        return hmac.compare_digest(ket_qua.hex(), hash_hex)
    except (ValueError, TypeError):
        return False
