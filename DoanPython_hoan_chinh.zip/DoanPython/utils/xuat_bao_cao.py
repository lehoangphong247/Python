import csv
from tkinter import filedialog, messagebox
from models.giao_dich import GiaoDich


def xuat_bao_cao_csv(user_id):
    du_lieu = GiaoDich.lay_tat_ca(user_id)
    if not du_lieu:
        messagebox.showinfo("Thông báo", "Chưa có giao dịch để xuất báo cáo.")
        return

    duong_dan = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("Tệp CSV", "*.csv")],
        initialfile="bao_cao_chi_tieu.csv"
    )
    if not duong_dan:
        return

    # utf-8-sig giúp Excel hiển thị tiếng Việt đúng hơn.
    with open(duong_dan, "w", newline="", encoding="utf-8-sig") as tep:
        writer = csv.writer(tep)
        writer.writerow(["Mã giao dịch", "Loại", "Danh mục",
                         "Số tiền (VND)", "Ngày", "Ghi chú"])
        for row in du_lieu:
            writer.writerow([
                row["id"], row["loai"], row["ten_danh_muc"] or "",
                row["so_tien"], row["ngay"], row["ghi_chu"] or ""
            ])

    messagebox.showinfo("Thành công", "Đã xuất báo cáo CSV.")
