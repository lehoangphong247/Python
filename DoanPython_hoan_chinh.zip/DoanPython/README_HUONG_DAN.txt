DO AN PYTHON - QUAN LY VA PHAN TICH CHI TIEU CA NHAN

1. Cai dat Python 3.10 tro len.
2. Mo Terminal trong VS Code tai thu muc DoanPython.
3. Cai thu vien:
   py -m pip install -r requirements.txt
4. Chay ung dung:
   py main.py

CHUC NANG:
- Dang ky, dang nhap, dang xuat.
- Du lieu rieng theo tung tai khoan.
- Quan ly giao dich thu/chi (them va xoa).
- Quan ly danh muc (them va xoa).
- Quan ly ngan sach theo thang.
- Tong quan thu nhap, chi tieu, so du.
- Thong ke theo thang.
- Xuat bao cao CSV.

DU LIEU:
- Co so du lieu SQLite duoc tao tu dong tai database/chi_tieu.db.
- Khong xoa tep database/chi_tieu.db neu muon giu du lieu da nhap.

LUU Y:
- Day la ban nen chay dau tien. Hay thu dang ky tai khoan moi truoc.
- Mat khau duoc bam PBKDF2-HMAC-SHA256 truoc khi luu.
- Ngay giao dich nhap theo YYYY-MM-DD.
- Thang ngan sach/thong ke nhap theo YYYY-MM.
