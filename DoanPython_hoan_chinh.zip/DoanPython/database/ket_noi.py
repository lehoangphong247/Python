import sqlite3
from pathlib import Path

THU_MUC_DU_AN = Path(__file__).resolve().parent.parent
DUONG_DAN_DB = THU_MUC_DU_AN / "database" / "chi_tieu.db"


def tao_ket_noi():
    """Tạo kết nối SQLite và bật kiểm tra khóa ngoại."""
    DUONG_DAN_DB.parent.mkdir(parents=True, exist_ok=True)
    ket_noi = sqlite3.connect(DUONG_DAN_DB)
    ket_noi.row_factory = sqlite3.Row
    ket_noi.execute("PRAGMA foreign_keys = ON")
    return ket_noi
