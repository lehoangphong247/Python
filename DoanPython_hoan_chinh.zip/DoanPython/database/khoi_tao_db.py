from database.ket_noi import tao_ket_noi


def khoi_tao_co_so_du_lieu():
    ket_noi = tao_ket_noi()
    cursor = ket_noi.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS nguoi_dung (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ho_ten TEXT NOT NULL,
            ten_dang_nhap TEXT NOT NULL UNIQUE,
            mat_khau_hash TEXT NOT NULL,
            ngay_tao TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS danh_muc (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nguoi_dung_id INTEGER NOT NULL,
            ten TEXT NOT NULL,
            loai TEXT NOT NULL CHECK(loai IN ('Thu nhập', 'Chi tiêu')),
            UNIQUE(nguoi_dung_id, ten, loai),
            FOREIGN KEY(nguoi_dung_id) REFERENCES nguoi_dung(id)
                ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS giao_dich (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nguoi_dung_id INTEGER NOT NULL,
            danh_muc_id INTEGER,
            loai TEXT NOT NULL CHECK(loai IN ('Thu nhập', 'Chi tiêu')),
            so_tien REAL NOT NULL CHECK(so_tien > 0),
            ngay TEXT NOT NULL,
            ghi_chu TEXT,
            FOREIGN KEY(nguoi_dung_id) REFERENCES nguoi_dung(id)
                ON DELETE CASCADE,
            FOREIGN KEY(danh_muc_id) REFERENCES danh_muc(id)
                ON DELETE SET NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ngan_sach (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nguoi_dung_id INTEGER NOT NULL,
            thang TEXT NOT NULL,
            so_tien REAL NOT NULL CHECK(so_tien > 0),
            UNIQUE(nguoi_dung_id, thang),
            FOREIGN KEY(nguoi_dung_id) REFERENCES nguoi_dung(id)
                ON DELETE CASCADE
        )
    """)

    ket_noi.commit()
    ket_noi.close()
