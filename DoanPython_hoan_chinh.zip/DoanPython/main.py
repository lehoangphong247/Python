import customtkinter as ctk
from database.khoi_tao_db import khoi_tao_co_so_du_lieu
from views.man_hinh_dang_nhap import ManHinhDangNhap

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


def main():
    khoi_tao_co_so_du_lieu()

    ung_dung = ctk.CTk()
    ung_dung.title("Quản lý và phân tích chi tiêu cá nhân")
    ung_dung.geometry("1200x760")
    ung_dung.minsize(1000, 650)

    ManHinhDangNhap(ung_dung).pack(fill="both", expand=True)
    ung_dung.mainloop()


if __name__ == "__main__":
    main()
