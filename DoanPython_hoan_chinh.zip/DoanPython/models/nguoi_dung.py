from database.ket_noi import tao_ket_noi
from utils.bao_mat import bam_mat_khau, kiem_tra_mat_khau


class NguoiDung:
    @staticmethod
    def dang_ky(ho_ten, ten_dang_nhap, mat_khau):
        ho_ten = ho_ten.strip()
        ten_dang_nhap = ten_dang_nhap.strip()

        if not ho_ten or not ten_dang_nhap or not mat_khau:
            return False, "Vui lòng nhập đầy đủ thông tin."

        if len(ten_dang_nhap) < 3:
            return False, "Tên đăng nhập phải có ít nhất 3 ký tự."

        if len(mat_khau) < 6:
            return False, "Mật khẩu phải có ít nhất 6 ký tự."

        ket_noi = tao_ket_noi()
        try:
            cursor = ket_noi.cursor()
            cursor.execute(
                "INSERT INTO nguoi_dung (ho_ten, ten_dang_nhap, mat_khau_hash) VALUES (?, ?, ?)",
                (ho_ten, ten_dang_nhap, bam_mat_khau(mat_khau))
            )
            user_id = cursor.lastrowid

            danh_muc_mac_dinh = [
                ("Lương", "Thu nhập"), ("Thưởng", "Thu nhập"),
                ("Thu nhập khác", "Thu nhập"),
                ("Ăn uống", "Chi tiêu"), ("Di chuyển", "Chi tiêu"),
                ("Mua sắm", "Chi tiêu"), ("Hóa đơn", "Chi tiêu"),
                ("Giải trí", "Chi tiêu"), ("Khác", "Chi tiêu")
            ]
            cursor.executemany(
                "INSERT INTO danh_muc (nguoi_dung_id, ten, loai) VALUES (?, ?, ?)",
                [(user_id, ten, loai) for ten, loai in danh_muc_mac_dinh]
            )
            ket_noi.commit()
            return True, "Đăng ký tài khoản thành công."
        except Exception as loi:
            ket_noi.rollback()
            if "UNIQUE constraint failed" in str(loi):
                return False, "Tên đăng nhập đã tồn tại."
            return False, f"Không thể đăng ký: {loi}"
        finally:
            ket_noi.close()

    @staticmethod
    def dang_nhap(ten_dang_nhap, mat_khau):
        ket_noi = tao_ket_noi()
        try:
            dong = ket_noi.execute(
                "SELECT * FROM nguoi_dung WHERE ten_dang_nhap = ?",
                (ten_dang_nhap.strip(),)
            ).fetchone()

            if dong and kiem_tra_mat_khau(mat_khau, dong["mat_khau_hash"]):
                return dict(dong)
            return None
        finally:
            ket_noi.close()
