from database.ket_noi import tao_ket_noi


class NganSach:
    @staticmethod
    def lay(user_id, thang):
        ket_noi = tao_ket_noi()
        try:
            row = ket_noi.execute(
                "SELECT * FROM ngan_sach WHERE nguoi_dung_id=? AND thang=?",
                (user_id, thang)
            ).fetchone()
            return dict(row) if row else None
        finally:
            ket_noi.close()

    @staticmethod
    def luu(user_id, thang, so_tien):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute("""
                INSERT INTO ngan_sach (nguoi_dung_id, thang, so_tien)
                VALUES (?, ?, ?)
                ON CONFLICT(nguoi_dung_id, thang)
                DO UPDATE SET so_tien=excluded.so_tien
            """, (user_id, thang, so_tien))
            ket_noi.commit()
            return True
        finally:
            ket_noi.close()
