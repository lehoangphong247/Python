from database.ket_noi import tao_ket_noi


class GiaoDich:
    @staticmethod
    def lay_tat_ca(user_id):
        ket_noi = tao_ket_noi()
        try:
            rows = ket_noi.execute("""
                SELECT g.id, g.loai, g.so_tien, g.ngay, g.ghi_chu,
                       d.ten AS ten_danh_muc
                FROM giao_dich g
                LEFT JOIN danh_muc d ON g.danh_muc_id = d.id
                WHERE g.nguoi_dung_id=?
                ORDER BY g.ngay DESC, g.id DESC
            """, (user_id,)).fetchall()
            return [dict(row) for row in rows]
        finally:
            ket_noi.close()

    @staticmethod
    def them(user_id, danh_muc_id, loai, so_tien, ngay, ghi_chu):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute("""
                INSERT INTO giao_dich
                (nguoi_dung_id, danh_muc_id, loai, so_tien, ngay, ghi_chu)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, danh_muc_id, loai, so_tien, ngay, ghi_chu.strip()))
            ket_noi.commit()
            return True, "Đã thêm giao dịch."
        except Exception as loi:
            return False, f"Không thể thêm giao dịch: {loi}"
        finally:
            ket_noi.close()

    @staticmethod
    def cap_nhat(user_id, giao_dich_id, danh_muc_id, loai, so_tien, ngay, ghi_chu):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute("""
                UPDATE giao_dich
                SET danh_muc_id=?, loai=?, so_tien=?, ngay=?, ghi_chu=?
                WHERE id=? AND nguoi_dung_id=?
            """, (danh_muc_id, loai, so_tien, ngay, ghi_chu.strip(),
                  giao_dich_id, user_id))
            ket_noi.commit()
            return True, "Đã cập nhật giao dịch."
        except Exception as loi:
            return False, f"Không thể cập nhật: {loi}"
        finally:
            ket_noi.close()

    @staticmethod
    def xoa(user_id, giao_dich_id):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute(
                "DELETE FROM giao_dich WHERE id=? AND nguoi_dung_id=?",
                (giao_dich_id, user_id)
            )
            ket_noi.commit()
            return True
        finally:
            ket_noi.close()

    @staticmethod
    def tong_quan(user_id):
        ket_noi = tao_ket_noi()
        try:
            rows = ket_noi.execute("""
                SELECT loai, COALESCE(SUM(so_tien), 0) AS tong
                FROM giao_dich WHERE nguoi_dung_id=? GROUP BY loai
            """, (user_id,)).fetchall()
            ket_qua = {"Thu nhập": 0, "Chi tiêu": 0}
            for row in rows:
                ket_qua[row["loai"]] = row["tong"]
            return ket_qua
        finally:
            ket_noi.close()

    @staticmethod
    def thong_ke_thang(user_id, thang):
        ket_noi = tao_ket_noi()
        try:
            rows = ket_noi.execute("""
                SELECT loai, COALESCE(SUM(so_tien), 0) AS tong
                FROM giao_dich
                WHERE nguoi_dung_id=? AND substr(ngay, 1, 7)=?
                GROUP BY loai
            """, (user_id, thang)).fetchall()
            result = {"Thu nhập": 0, "Chi tiêu": 0}
            for row in rows:
                result[row["loai"]] = row["tong"]
            return result
        finally:
            ket_noi.close()
