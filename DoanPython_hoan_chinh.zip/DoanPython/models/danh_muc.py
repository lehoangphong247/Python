from database.ket_noi import tao_ket_noi


class DanhMuc:
    @staticmethod
    def lay_tat_ca(user_id, loai=None):
        ket_noi = tao_ket_noi()
        try:
            if loai:
                rows = ket_noi.execute(
                    "SELECT * FROM danh_muc WHERE nguoi_dung_id=? AND loai=? ORDER BY ten",
                    (user_id, loai)
                ).fetchall()
            else:
                rows = ket_noi.execute(
                    "SELECT * FROM danh_muc WHERE nguoi_dung_id=? ORDER BY loai, ten",
                    (user_id,)
                ).fetchall()
            return [dict(row) for row in rows]
        finally:
            ket_noi.close()

    @staticmethod
    def them(user_id, ten, loai):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute(
                "INSERT INTO danh_muc (nguoi_dung_id, ten, loai) VALUES (?, ?, ?)",
                (user_id, ten.strip(), loai)
            )
            ket_noi.commit()
            return True, "Đã thêm danh mục."
        except Exception as loi:
            return False, "Danh mục đã tồn tại hoặc dữ liệu không hợp lệ."
        finally:
            ket_noi.close()

    @staticmethod
    def xoa(user_id, danh_muc_id):
        ket_noi = tao_ket_noi()
        try:
            ket_noi.execute(
                "DELETE FROM danh_muc WHERE id=? AND nguoi_dung_id=?",
                (danh_muc_id, user_id)
            )
            ket_noi.commit()
            return True
        finally:
            ket_noi.close()
